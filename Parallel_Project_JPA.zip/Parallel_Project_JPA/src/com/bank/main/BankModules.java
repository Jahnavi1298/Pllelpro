package com.bank.main;

import java.util.Scanner;

import com.bank.entity.BankDetails;
import com.bank.entity.TransactionDetails;
import com.bank.service.BankService;
import com.bank.service.Validator;

public class BankModules {
	
	Scanner scan = new Scanner(System.in);
	BankService bankService;
	BankDetails bankDet;
	Validator validator;
	TransactionDetails transactionDet1;
	TransactionDetails transactionDet2 = new TransactionDetails();

	public void createAccount() throws InvalidException {
		bankService = new BankService();
		bankDet = new BankDetails();
		validator = new Validator();
		System.out.print("Enter Account Holder Name: ");
		String name = scan.next();
		if(validator.isNameValid(name)) {
			bankDet.setName(name);
			System.out.print("Enter initial amount: ");
			int amount = scan.nextInt();
			if(validator.isBalanceValid(amount)) {
				bankDet.setAccBalance(amount);
				System.out.print("Enter Mobile Number: ");
				String mobileNo = scan.next();
				bankDet.setMobileno(mobileNo);
				bankDet.setAccNo();
				bankService.createAccount(bankDet);
				System.out.println("Account Created Successfully");
				int id = bankDet.getAccNo();
				bankService.getAccountById(id);
				System.out.println("Your Account number is: " + bankDet.getAccNo());
			}
			else {
				throw new InvalidException("Enter valid amount");
			}
		}
		else {
			throw new InvalidException("Enter valid name");
		}
	}
	
	public void showBalance() throws InvalidException {
		bankService = new BankService();
		bankDet = new BankDetails();
		validator = new Validator();
		System.out.print("Enter your account number: ");
		int accountNo = scan.nextInt();
		if (validator.isAccountNumberValid(accountNo)) {
			bankDet = bankService.getAccountById(accountNo);
			System.out.println("Name: " + bankDet.getName());
			System.out.println("Your Account Balance is: " + bankDet.getAccBalance());
		}
		else {
			throw new InvalidException("Enter valid Account Number");
		}
	}
	
	public void deposit() throws InvalidException {
		bankService = new BankService();
		bankDet = new BankDetails();
		validator = new Validator();
		System.out.print("Enter your Account number: ");
		int accountNo = scan.nextInt();
		if (validator.isAccountNumberValid(accountNo)) {
			bankDet = bankService.getAccountById(accountNo);
			System.out.println("Name: " + bankDet.getName());
			System.out.println("Your Account Balance is: " + bankDet.getAccBalance());
			int initBal = bankDet.getAccBalance();
			System.out.print("Enter the Amount you want to Deposit: ");
			int depAmt = scan.nextInt();
			if(validator.isBalanceValid(depAmt)) {
				bankDet.setAccBalance(initBal + depAmt);
				bankService.deposit(bankDet);

				// Updating In Transaction Table
				
				transactionDet2.setTransactionType("Deposit");
				transactionDet2.setAccId(accountNo);
				transactionDet2.setAmount(depAmt);
				bankService.addTransaction(transactionDet2);
				bankDet.setT(transactionDet2);
				System.out.println("Your Account Balance after Depositing: " +bankDet.getAccBalance());
			}
			else {
				throw new InvalidException("Enter valid amount");
			}
		}
		else {
			throw new InvalidException("Enter valid Account number");
		}
	}
	
	public void withdraw() throws InvalidException {
		bankService = new BankService();
		bankDet = new BankDetails();
		validator = new Validator();
		System.out.print("Enter your Account number: ");
		int accountNo = scan.nextInt();
		if (validator.isAccountNumberValid(accountNo)) {
			bankDet = bankService.getAccountById(accountNo);
			System.out.println(" Your Account Balance is: " + bankDet.getAccBalance());
			int initBal = bankDet.getAccBalance(); // initial balance
			
			System.out.print("Enter the Amount you to Withdraw: ");
			int amount = scan.nextInt();
			
			if(validator.isBalanceValid(amount) && (initBal>amount)) {
				bankDet.setAccBalance(initBal - amount);
				bankService.withdraw(bankDet);

				// Updating In Transaction Table
				
				transactionDet2.setTransactionType("Withdraw");
				transactionDet2.setAccId(accountNo);
				transactionDet2.setAmount(amount);
				bankService.addTransaction(transactionDet2);
				bankDet.setT(transactionDet2);

				bankDet = bankService.getAccountById(accountNo);
				System.out.println("Hello " + bankDet.getName());
				System.out.println("Your Remaining Account Balance after Withdraw: " +bankDet.getAccBalance());
			}
			else {
				throw new InvalidException("Enter valid Amount");
			}
		}
		else {
			throw new InvalidException("Enter valid Account Number");
		}
	}
	
	public void fundTransfer() throws InvalidException {
		bankService = new BankService();
		bankDet = new BankDetails();
		validator = new Validator();
		transactionDet1 = new TransactionDetails();
		System.out.print("Enter the Sender Account Number: ");
		int senderAccNo = scan.nextInt(); // From Account Id (Sender)
		if (validator.isAccountNumberValid(senderAccNo)) {
			bankDet = bankService.getAccountById(senderAccNo);
			int senderBalance = bankDet.getAccBalance(); // Initial Balance
			System.out.println("Enter the amount you want to transfer");
			int amount = scan.nextInt(); // Amount to be transfered
			if(validator.isBalanceValid(amount)) {
				
				System.out.print("Enter Reciever Account Number: ");
				int recAccNo = scan.nextInt();
				
				if (validator.isAccountNumberValid(recAccNo)) {
					// Removing the Balance transfered from sender Account
					
					bankDet = bankService.getAccountById(senderAccNo);
					int remBalance = senderBalance - amount;
					bankDet.setAccBalance(remBalance);
					bankService.deposit(bankDet);

					// updating the Balance recieved from Sender
					
					bankDet = bankService.getAccountById(recAccNo);
					int initBalance = bankDet.getAccBalance();
					int updateBalance = initBalance + amount;
					bankDet.setAccBalance(updateBalance);
					bankService.deposit(bankDet);

					// updating In transaction Table
					
					transactionDet1.setTransactionType("Transfered to " + recAccNo);
					transactionDet1.setAccId(senderAccNo);
					transactionDet1.setAmount(amount);
					bankService.addTransaction(transactionDet1);
					bankDet.setT(transactionDet1);
					int k = transactionDet1.getTransactionId();

					/*
					 * //Updating In transaction Table trans1.setTransactionId(k);
					 * trans1.setTransactionType("Recieved From"+fid); trans1.setAccId(tid);
					 * trans1.setAmount(fund); service.addTransaction(trans1); bank.setT(trans1);
					 * 
					 */

					bankDet = bankService.getAccountById(senderAccNo);
					System.out.println("Remaining balance in account " +bankDet.getAccBalance());
				}
				else {
					throw new InvalidException("Enter valid Account Number");
				}
			}
			else {
				throw new InvalidException("Enter valid Amount");
			}
		}
		else {
			throw new InvalidException("Enter Valid Account Number");
		}
	}
	
	public void printTransactions() throws InvalidException {
		bankService = new BankService();
		validator = new Validator();
		System.out.print("Enter Account number: ");
		int accountNo = scan.nextInt();
		if(validator.isAccountNumberValid(accountNo)) {
			bankService.printTransactions(accountNo);
		}
		else {
			throw new InvalidException("Enter Valid Account Number");
		}
	}
	
}
