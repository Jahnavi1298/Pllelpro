package com.bank.main;

public class  InvalidException extends Exception {
public InvalidException(String mesg){
	System.out.println(mesg);
}
}
